
  # Arabic Reading Learning App

  This is a code bundle for Arabic Reading Learning App. The original project is available at https://www.figma.com/design/PEsc8Slp9qGhuOtnBADqRR/Arabic-Reading-Learning-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  